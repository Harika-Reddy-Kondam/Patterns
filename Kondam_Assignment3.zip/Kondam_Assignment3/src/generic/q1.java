package generic;

public class q1 {
    public static void main(String[] args) {
        Box<String> stringBox = new Box<>();
        stringBox.setData("Hello, World!");
        System.out.println(stringBox.getData()); // Output: Hello, World!
        
        Box<Integer> intBox = new Box<>();
        intBox.setData(42);
        System.out.println(intBox.getData()); // Output: 42
    }
}

class Box<T> {
    private T data;

    public void setData(T data) {
        this.data = data;
    }

    public T getData() {
        return this.data;
    }
}

