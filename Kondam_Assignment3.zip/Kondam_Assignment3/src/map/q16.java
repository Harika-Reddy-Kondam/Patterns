package map;

import java.util.HashMap;

public class q16 {
	  public static void main(String[] args) {
	    HashMap<Integer, String> hashMap = new HashMap<Integer, String>();

	    hashMap.put(1, "One");
	    hashMap.put(2, "Two");
	    hashMap.put(3, "Three");

	    String value = hashMap.get(2);

	    System.out.println(value); // Output: Two
	  }
	}
