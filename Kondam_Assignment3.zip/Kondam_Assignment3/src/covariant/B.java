package covariant;

class A {
	   A get() {
	      System.out.println("Harika");
	      return this;
	   }
	}
public class B extends A {
	   B get() {
	      System.out.println("Hyndavi");
	      return this;
	   }
	   public static void main(String[] args) {
	      A tester = new B();
	      tester.get();
	   }
}    
    