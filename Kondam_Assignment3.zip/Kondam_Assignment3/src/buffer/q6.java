package buffer;

public class q6 {
    public static void main(String[] args) {
        String stg = "Web";
        stg += "Mining"; // This generates a new string object and assigns it to the variable str.
        StringBuffer stgBfr = new StringBuffer("My");
        stgBfr.append("Name"); // The existing StringBuffer object is modified.

        String optStr = stg.toString();
        String optStrgBfr = stgBfr.toString();

        System.out.println(optStr);
        System.out.println(optStrgBfr); 
    }
}
