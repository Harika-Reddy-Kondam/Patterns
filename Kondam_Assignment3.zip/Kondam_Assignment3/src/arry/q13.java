package arry;

import java.util.Vector;
import java.util.ArrayList;

public class q13 {
    public static void main(String[] args) {
        // Creating a Vector
        Vector<String> vector = new Vector<>();

        // Adding elements to Vector
        vector.add("John");
        vector.add("Mary");
        vector.add("Daniel");

        // Accessing elements in Vector
        System.out.println("Elements in Vector:");
        for (String element : vector) {
            System.out.println(element);
        }

        // Creating an ArrayList
        ArrayList<Integer> arrayList = new ArrayList<>();

        // Adding elements to ArrayList
        arrayList.add(1);
        arrayList.add(2);
        arrayList.add(3);

        // Accessing elements in ArrayList
        System.out.println("Elements in ArrayList:");
        for (int i = 0; i < arrayList.size(); i++) {
            System.out.println(arrayList.get(i));
        }
    }
}

