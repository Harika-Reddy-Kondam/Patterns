package members;

public class q2 {
    protected void protectedMethod() {
        // implementation
    }
}

//public class Subclass extends Superclass {
//    public void protectedMethod() {
//        // new implementation
//    }
//}
