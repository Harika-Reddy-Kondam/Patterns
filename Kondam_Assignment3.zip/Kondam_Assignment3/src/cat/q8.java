package cat;

public class q8 {
	   public static void main(String[] args) {
	      try {
	         System.out.println("try");
	      } finally {
	         System.out.println("finally");
	      }
	   }
}
