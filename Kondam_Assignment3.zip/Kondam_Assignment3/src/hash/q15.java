package hash;

import java.util.Hashtable;

public class q15 {
	  public static void main(String[] args) {
	    Hashtable<Integer, String> hashtable = new Hashtable<Integer, String>();

	    hashtable.put(1, "One");
	    hashtable.put(2, "Two");
	    hashtable.put(3, "Three");

	    String value = hashtable.get(2);

	    System.out.println(value); // Output: Two
	  }
	}

