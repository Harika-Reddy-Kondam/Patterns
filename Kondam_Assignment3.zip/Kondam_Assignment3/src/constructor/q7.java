package constructor;

public class q7
{
    final X(){
        System.out.println("Final Constructor");
    }
	public static final void main(String[] args) {
	   A obj1 = new A();
	}
}



