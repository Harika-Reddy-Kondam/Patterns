package singleton;

public class q27 {
    private static q27 instance = null;

    private q27() {
        // private constructor to prevent instantiation from outside
    }

    public static synchronized q27 getInstance() {
        if (instance == null) {
            instance = new q27();
        }
        return instance;
    }

    public static void main(String[] args) {
        q27 singleton1 = q27.getInstance();
        q27 singleton2 = q27.getInstance();
        System.out.println("Are singleton1 and singleton2 the same instance? " + (singleton1 == singleton2));
    }
}

