package finl;

public final class q12 {
	   public static final int MY_CONSTANT = 42;
	   protected void finalize() throws Throwable {
		      // this code will be executed by the garbage collector before destroying the object
		      // ...
		   }
	   public static void main(String[] args) {
		   try {
	            // Code that may throw an exception
	            int result = 10 / 0; // This will throw an ArithmeticException
	        } catch (ArithmeticException e) {
	            // Exception handling code
	            System.out.println("Error: " + e.getMessage()); // Output: Error: / by zero
	        } finally {
	            // This code will always be executed, whether an exception is thrown or not
	            System.out.println("Finally block executed");
	        }

	}
}