package runnable;

public class q19 implements Runnable {
    public void run() {
        System.out.println("MyRunnable running");
    }
}


