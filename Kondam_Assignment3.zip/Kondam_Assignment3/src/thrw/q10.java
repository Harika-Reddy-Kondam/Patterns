package thrw;

import java.io.IOException;

class q10 {
    void myMethod() throws IOException {
        // implementation
    }
}

class Subclass extends q10 {
    void myMethod() throws IOException {
        // implementation
    }
}
