package builder;

public class q5 {
    public static void main(String[] args) {
        StringBuffer stringBuffer = new StringBuffer();
        stringBuffer.append("Hello");
        stringBuffer.append(" ");
        stringBuffer.append("world");

        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Hello");
        stringBuilder.append(" ");
        stringBuilder.append("world");

        String outputStringBuffer = stringBuffer.toString();
        String outputStringBuilder = stringBuilder.toString();

        System.out.println(outputStringBuffer); // Output: "Hello world"
        System.out.println(outputStringBuilder); // Output: "Hello world"
    }
}
