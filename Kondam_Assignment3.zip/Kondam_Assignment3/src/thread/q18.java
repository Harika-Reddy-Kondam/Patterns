package thread;

class MyThread extends Thread {
	  public void run() {
	    System.out.println("Hello Thread!");
	  }
	}

	public class q18 {
	  public static void main(String[] args) {
	    MyThread thread = new MyThread();
	    thread.start();
	  }
}